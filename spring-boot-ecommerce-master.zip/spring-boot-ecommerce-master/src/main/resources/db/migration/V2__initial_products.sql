INSERT INTO customer (created_at, modified_at, "name")
    values(now(), now(), 'Nielsen Costa Teixeira');


INSERT INTO product (created_at, modified_at, "name", description)
    values (now(), now(), 'Kimono Atama', 'Kimono branco tamanho A2'),
           (now(), now(), 'Kimono Koral', 'Kimono preto tamanho A3'),
           (now(), now(), 'Faixa Branca', 'Faixa branca tamanho A2'),
           (now(), now(), 'Faixa Azul', 'Faixa azul tamanho A2'),
           (now(), now(), 'Faixa Roxa', 'Faixa roxa tamanho A2'),
           (now(), now(), 'Faixa Marrom', 'Faixa marrom tamanho A2'),
           (now(), now(), 'Faixa Preta', 'Faixa preta tamanho A2');