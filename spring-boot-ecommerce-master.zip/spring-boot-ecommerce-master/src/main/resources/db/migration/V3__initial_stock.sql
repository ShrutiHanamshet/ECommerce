INSERT INTO stock_item (created_at, modified_at, product_id, amount, price)
    values (now(), now(), 1, 10, 599.9),
           (now(), now(), 2, 10, 280.0),
           (now(), now(), 3, 10, 34.9),
           (now(), now(), 4, 5, 34.9),
           (now(), now(), 5, 5, 34.9),
           (now(), now(), 6, 3, 34.9),
           (now(), now(), 7, 2, 34.9);