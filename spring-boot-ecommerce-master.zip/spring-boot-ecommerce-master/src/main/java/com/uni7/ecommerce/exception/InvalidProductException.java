package com.uni7.ecommerce.exception;

public class InvalidProductException extends Exception {
    public InvalidProductException(String message) {
        super(message);
    }
}
