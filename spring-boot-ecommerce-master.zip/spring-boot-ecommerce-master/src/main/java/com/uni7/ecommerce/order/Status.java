package com.uni7.ecommerce.order;

public enum Status {
    OPEN,
    FINALIZED
}
